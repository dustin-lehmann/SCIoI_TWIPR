/*
 * twipr.h
 *
 *  Created on: Feb 22, 2023
 *      Author: lehmann_workstation
 */

#ifndef CORE_TWIPR_H_
#define CORE_TWIPR_H_




class TWIPR {
public:

private:

};



#endif /* CORE_TWIPR_H_ */

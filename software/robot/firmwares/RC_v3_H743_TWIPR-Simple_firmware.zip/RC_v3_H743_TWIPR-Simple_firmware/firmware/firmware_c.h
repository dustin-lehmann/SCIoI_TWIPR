/*
 * firmware_c.h
 *
 *  Created on: Feb 13, 2023
 *      Author: lehmann_workstation
 */

#ifndef FIRMWARE_C_H_
#define FIRMWARE_C_H_

void firmware();

#endif /* FIRMWARE_C_H_ */

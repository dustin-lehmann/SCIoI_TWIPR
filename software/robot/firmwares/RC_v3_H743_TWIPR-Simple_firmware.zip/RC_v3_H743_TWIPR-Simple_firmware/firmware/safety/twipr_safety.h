/*
 * twipr_safety.h
 *
 *  Created on: Feb 22, 2023
 *      Author: lehmann_workstation
 */

#ifndef SAFETY_TWIPR_SAFETY_H_
#define SAFETY_TWIPR_SAFETY_H_

#include "core.h"

class TWIPR_Safety {
public:
	TWIPR_Safety();
private:
};

#endif /* SAFETY_TWIPR_SAFETY_H_ */

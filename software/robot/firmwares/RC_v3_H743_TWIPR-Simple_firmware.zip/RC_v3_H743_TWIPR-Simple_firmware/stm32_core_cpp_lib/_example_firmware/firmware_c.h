/*
 * core_c.h
 *
 *  Created on: Jul 17, 2022
 *      Author: lehmann_workstation
 */

#ifndef CORE_CORE_C_H_
#define CORE_CORE_C_H_



#endif /* CORE_CORE_C_H_ */

/*
 * core_defs.h
 *
 *  Created on: 8 Jul 2022
 *      Author: Dustin Lehmann
 */

#ifndef CORE_CORE_DEFS_H_
#define CORE_CORE_DEFS_H_


#define CORE_OK 1
#define CORE_ERROR 0


#endif /* CORE_CORE_DEFS_H_ */

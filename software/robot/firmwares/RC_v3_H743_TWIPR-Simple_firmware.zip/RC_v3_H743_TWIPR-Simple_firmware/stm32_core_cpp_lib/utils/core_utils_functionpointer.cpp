/*
 * core_utils_functionpointer.cpp
 *
 *  Created on: 23 Feb 2023
 *      Author: lehmann_workstation
 */

#include "core_utils_functionpointer.h"



